package com.adamm.psu.afinal;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity implements View.OnClickListener{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        Button okButton = findViewById(R.id.okButton);
        okButton.setOnClickListener(this);



    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            default:
                finishScreen();
                break;

        }
    }

    private void finishScreen() {
        finish();
    }
}
