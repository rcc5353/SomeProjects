package com.adamm.psu.afinal;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener{

    public static final String RESULT_SETTINGS_CHANGE_THEME = "SHOULD_CHANGE_THEME";

    private SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(this);
        
        Button playButton = findViewById(R.id.playButton);
        playButton.setOnClickListener(this);
        
        sharedPreferences = getSharedPreferences(getString(R.string.shared_pref), MODE_PRIVATE);

    }

    @Override
    public void onClick(View view) {

        switch(view.getId()){
            case R.id.settingsButton:
                handleSettingsButton();
                break;
            case R.id.playButton:
                handlePlayButton();
                break;
            default:
                break;
                
        }
        
    }
    ActivityResultLauncher<Intent> mGetStatus = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() { @Override
    public void onActivityResult(ActivityResult result) {

        int resultCode = result.getResultCode();
        switch (resultCode){
            case RESULT_OK:

                finish();
                break;
            case RESULT_CANCELED:
                Log.d("Final","Cancelled from SettingsActivity");
                break;

        }

    }
    });

    ActivityResultLauncher<Intent> pGetStatus = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() { @Override
    public void onActivityResult(ActivityResult result) {

        int resultCode = result.getResultCode();
        switch (resultCode){
            case RESULT_OK:

                finish();
                break;
            case RESULT_CANCELED:
                Log.d("Final","Cancelled from SettingsActivity");
                break;

        }

    }
    });


        private void handleSettingsButton() {

        Intent intent = new Intent(this, SettingsActivity.class);
        mGetStatus.launch(intent);


    }

    private void handlePlayButton() {
            Intent intent = new Intent(this, PlayActivity.class);
            pGetStatus.launch(intent);
    }
}
