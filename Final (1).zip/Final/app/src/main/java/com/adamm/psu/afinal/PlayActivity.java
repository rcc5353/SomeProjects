package com.adamm.psu.afinal;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Random;

public class PlayActivity extends AppCompatActivity implements View.OnClickListener{
    private HashMap<String, Integer> listOfLogos = new LinkedHashMap<>();
    private ArrayList imgList = new ArrayList();
    private AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        builder = new AlertDialog.Builder(this);


        Button guessOne = findViewById(R.id.guessOne);
        Button guessTwo = findViewById(R.id.guessTwo);
        Button guessThree = findViewById(R.id.guessThree);
        Button guessFour = findViewById(R.id.guessFour);
        ImageView aboutButton = findViewById(R.id.aboutButtonPlay);
        ImageView settingsButton = findViewById(R.id.settingsButtonPlay);

        ImageView logo = findViewById(R.id.logoToGuess);

        Random random = new Random();


        guessOne.setOnClickListener(this);
        guessTwo.setOnClickListener(this);
        guessThree.setOnClickListener(this);
        guessFour.setOnClickListener(this);
        aboutButton.setOnClickListener(this);
        settingsButton.setOnClickListener(this);

        listOfLogos.put(getString(R.string.psu), R.drawable.psulogo);
        listOfLogos.put(getString(R.string.umd), R.drawable.umdlogo);
        listOfLogos.put(getString(R.string.purdue), R.drawable.purdue);
        listOfLogos.put(getString(R.string.umich), R.drawable.umich);

        imgList.add(getDrawable(R.drawable.psulogo));
        imgList.add(getDrawable(R.drawable.purdue));
        imgList.add(getDrawable(R.drawable.umdlogo));
        imgList.add(getDrawable(R.drawable.umich));

        int randIndex = random.nextInt(listOfLogos.size());

        String key = (new ArrayList<>(listOfLogos.keySet())).get(randIndex);

        //Drawable newImg = getDrawable(imgList.get(randIndex));

        logo.setImageDrawable((Drawable) getDrawable(listOfLogos.get(key)));
        logo.setTag(key);

    }


    @Override
    public void onClick(View view) {

        switch(view.getId()){
            case R.id.guessOne:
                boolean ifCorrect = checkGuess(R.id.guessOne);
                correctGuess(ifCorrect);
                break;
            case R.id.guessFour:
                 ifCorrect = checkGuess(R.id.guessFour);
                correctGuess(ifCorrect);
                break;
            case R.id.guessTwo:
                 ifCorrect = checkGuess(R.id.guessTwo);
                correctGuess(ifCorrect);
                break;
            case R.id.guessThree:
                 ifCorrect = checkGuess(R.id.guessThree);
                correctGuess(ifCorrect);
                break;
            case R.id.aboutButtonPlay:
                handleAboutButton();
                break;
            case R.id.settingsButtonPlay:
                handleSettingsButton();
                break;
            default:
                break;

        }

    }

    private void correctGuess(boolean guess) {

        if (guess){
            builder.setMessage(R.string.correctMessage).setTitle(R.string.correctTitle);
            builder.setPositiveButton(R.string.newGame, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                    startActivity(getIntent());

                }
            });
            builder.setNegativeButton(R.string.goHome, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }  if (!guess){

            builder.setMessage(R.string.incorrectMessage).setTitle(R.string.incorrectTitle);
            builder.setPositiveButton(R.string.newGame, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                    startActivity(getIntent());
                }
            });
            builder.setNegativeButton(R.string.goHome, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();

        }
    }


    private boolean checkGuess(int buttonId){

        Button guess = findViewById(buttonId);
        String schoolGuess = guess.getText().toString();

        ImageView logo = findViewById(R.id.logoToGuess);
        String test = logo.getTag().toString();



        if (test.equalsIgnoreCase(schoolGuess)) {

            guess.setBackgroundColor(getResources().getColor(R.color.correct));
            return true;
                }
        else {
            guess.setBackgroundColor(getResources().getColor(R.color.incorrect));

            return false;
        }

    }

    private void handleSettingsButton() {
        Intent goToSettings = new Intent(this, SettingsActivity.class);
        PlayActivity.this.startActivity(goToSettings);
    }

    private void handleAboutButton() {
        Intent goToAbout = new Intent(this, AboutActivity.class);
        PlayActivity.this.startActivity(goToAbout);
    }
}
